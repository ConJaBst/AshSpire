ServerEvents.recipes(event => {
  // Add custom sequenced assembly
  event.recipes.create.sequenced_assembly(
    ['create:item_vault'],                  // Final result
    'minecraft:chest',                      // Base item
    [
      event.recipes.create.deploying(
        'minecraft:chest',
        ['minecraft:chest', 'create:iron_sheet']
      ),
    ]
  )
  .transitionalItem('minecraft:chest')
  .loops(2)
})

ServerEvents.recipes(event => {
  // Add custom sequenced assembly
  event.recipes.create.sequenced_assembly(
    ['create:fluid_tank'],                  // Final result
    'minecraft:chest',                      // Base item
    [
      event.recipes.create.deploying(
        'minecraft:chest',
        ['minecraft:chest', 'create:copper_sheet']
      ),
    ]
  )
  .transitionalItem('minecraft:chest')
  .loops(2)
})