ServerEvents.recipes(event => {
  // Add custom sequenced assembly
  event.recipes.create.sequenced_assembly(
    ['create:item_vault'],                  // Final result
    'minecraft:chest',                      // Base item
    [
      event.recipes.create.deploying(
        'minecraft:chest',
        ['minecraft:chest', 'create:iron_sheet']
      ),
    ]
  )
  .transitionalItem('minecraft:chest')
  .loops(2)
})

ServerEvents.recipes(event => {
  // Add custom sequenced assembly
  event.recipes.create.sequenced_assembly(
    ['create:fluid_tank'],                  // Final result
    'minecraft:chest',                      // Base item
    [
      event.recipes.create.deploying(
        'minecraft:chest',
        ['minecraft:chest', 'create:copper_sheet']
      ),
    ]
  )
  .transitionalItem('minecraft:chest')
  .loops(2)
})


//Pizza assembly 
ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    
    Item.of('brewinandchewin:pizza').withChance(1.0)
    
  ], '#forge:dough', [
    event.recipes.create.pressing('create:dough', 'create:dough'),
    
    event.recipes.create.filling('create:dough', ['create:dough', Fluid.of('create_central_kitchen:tomato_sauce', 250)]),
    
    event.recipes.create.deploying('create:dough', ['create:dough', '#brewinandchewin:cheese_wedges']),
    
    event.recipes.create.deploying('create:dough', ['create:dough', '#brewinandchewin:pizza_toppings'])
    
  ]).transitionalItem('create:dough').loops(1);
})

//Shulker Shell assembly
ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    Item.of('minecraft:shulker_shell').withChance(0.85),
    
    Item.of('minecraft:popped_chorus_fruit').withChance(0.10),
    
    Item.of('minecraft:purpur_slab').withChance(0.05),
    
    Item.of('minecraft:ender_pearl').withChance(0.15)
    
  ], 'minecraft:purpur_slab', [
    event.recipes.create.cutting('minecraft:purpur_slab', 'minecraft:purpur_slab').processingTime(600),
    
    event.recipes.create.pressing('minecraft:purpur_slab', 'minecraft:purpur_slab'),
    
    event.recipes.create.deploying('minecraft:purpur_slab', ['minecraft:purpur_slab', 'minecraft:popped_chorus_fruit']),
    
    event.recipes.create.filling('minecraft:purpur_slab', ['minecraft:purpur_slab', Fluid.of('create:potion', 250, {Bottle:"REGULAR", Potion:"minecraft:strength"})]),
    
    event.recipes.create.filling('minecraft:purpur_slab', ['minecraft:purpur_slab', Fluid.of('create:potion', 250, {Bottle:"REGULAR", Potion:"minecraft:regeneration"})]),
    
    event.recipes.create.pressing('minecraft:purpur_slab', 'minecraft:purpur_slab')
    
  ]).transitionalItem('minecraft:purpur_slab').loops(4);
})

//Chorus Totem 
ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    Item.of('artifacts:chorus_totem').withChance(1.0)

  ], 'minecraft:purpur_slab', [
    event.recipes.create.deploying('minecraft:totem_of_undying', ['minecraft:totem_of_undying', 'minecraft:ender_pearl']),
    
    event.recipes.create.deploying('minecraft:totem_of_undying', ['minecraft:totem_of_undying', 'minecraft:ender_pearl']),
    
    event.recipes.create.deploying('minecraft:totem_of_undying', ['minecraft:totem_of_undying', 'minecraft:ender_pearl']),
    
    event.recipes.create.deploying('minecraft:totem_of_undying', ['minecraft:totem_of_undying', 'minecraft:chorus_fruit']),
    
    event.recipes.create.pressing('minecraft:totem_of_undying', 'minecraft:totem_of_undying'),
    
    event.recipes.create.deploying('minecraft:totem_of_undying', ['minecraft:totem_of_undying', 'minecraft:purpur_slab']),
    
    event.recipes.create.deploying('minecraft:totem_of_undying', ['minecraft:totem_of_undying', 'minecraft:lead'])
    
  ]).transitionalItem('minecraft:totem_of_undying').loops(2);
})

//Rooted Boots
ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    Item.of('artifacts:rooted_boots').withChance(1.0)

  ], 'minecraft:leather_boots', [
    event.recipes.create.deploying('minecraft:leather_boots', ['minecraft:leather_boots', 'minecraft:vine']),
    
    event.recipes.create.deploying('minecraft:leather_boots', ['minecraft:leather_boots', 'minecraft:vine']),
    
    event.recipes.create.deploying('minecraft:leather_boots', ['minecraft:leather_boots', 'minecraft:vine']),
    
    event.recipes.create.filling('minecraft:leather_boots', ['minecraft:leather_boots', Fluid.of('create:potion', 250, {Bottle:"REGULAR", Potion:"minecraft:regeneration"})])
    
  ]).transitionalItem('minecraft:leather_boots').loops(1);
})

//Angler Hat 
ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    Item.of('artifacts:anglers_hat').withChance(1.0)

  ], 'minecraft:leather_helmet', [
    event.recipes.create.deploying('minecraft:leather_helmet', ['minecraft:leather_helmet', 'minecraft:cod']),
    
    event.recipes.create.deploying('minecraft:leather_helmet', ['minecraft:leather_helmet', 'farmersdelight:canvas']),
    
    event.recipes.create.deploying('minecraft:leather_helmet', ['minecraft:leather_helmet', 'farmersdelight:canvas']),
    
    event.recipes.create.deploying('minecraft:leather_helmet', ['minecraft:leather_helmet', 'minecraft:feather']),
    
    event.recipes.create.filling('minecraft:leather_helmet', ['minecraft:leather_helmet', Fluid.of('create:potion', 1000, {Bottle:"REGULAR", Potion:"minecraft:water_breathing"})])
    
  ]).transitionalItem('minecraft:leather_helmet').loops(2);
})

ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    Item.of('artifacts:villager_hat').withChance(1.0)

  ], 'minecraft:wheat', [
    event.recipes.create.deploying('minecraft:wheat', ['minecraft:wheat', 'numismatics:spur']),
    
    event.recipes.create.deploying('minecraft:wheat', ['minecraft:wheat', 'minecraft:emerald']),
    
    event.recipes.create.deploying('minecraft:wheat', ['minecraft:wheat', 'minecraft:wheat']),
    
    event.recipes.create.deploying('minecraft:wheat', ['minecraft:wheat', 'farmersdelight:canvas']),
    
    event.recipes.create.deploying('minecraft:wheat', ['minecraft:wheat', 'farmersdelight:straw'])
    
  ]).transitionalItem('minecraft:leather_helmet').loops(12);
})

ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    Item.of('artifacts:fire_gauntlet').withChance(1.0)

  ], 'artifacts:power_glove', [
    event.recipes.create.filling('artifacts:power_glove', ['artifacts:power_glove', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:fire_resistance"})]),
    
   event.recipes.create.filling('artifacts:power_glove', ['artifacts:power_glove', Fluid.of('minecraft:lava', 1000 )])
    
  ]).transitionalItem('artifacts:power_glove').loops(24);
})

ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    Item.of('minecraft:snowball').withChance(0.75),
    
    Item.of('2x minecraft:snowball').withChance(0.15),
    
    Item.of('5x minecraft:snowball').withChance(0.10)

  ], 'minecraft:ice', [
    
    event.recipes.create.cutting('minecraft:ice', 'minecraft:ice').processingTime(150),
    
    event.recipes.create.pressing('minecraft:ice', 'minecraft:ice')
    
  ]).transitionalItem('minecraft:ice').loops(6);
})

ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    Item.of('ashspire:andesite_mechanism').withChance(128.0),
    Item.of('create:andesite_alloy').withChance(0.30),
    Item.of('create:copper_nugget').withChance(0.29),
    Item.of('minecraft:iron_nugget').withChance(0.19),
    Item.of('create:zinc_nugget').withChance(0.08),
    Item.of('minecraft:clock').withChance(0.05)

  ], 'ashspire:andesite_sheet', [
    event.recipes.create.deploying('ashspire:andesite_sheet', ['ashspire:andesite_sheet', 'createaddition:capacitor']),
    
    event.recipes.create.deploying('ashspire:andesite_sheet', ['ashspire:andesite_sheet', 'ashspire:copper_gear']),
    
    event.recipes.create.deploying('ashspire:andesite_sheet', ['ashspire:andesite_sheet', 'ashspire:copper_gear'])
    
    
  ]).transitionalItem('ashspire:andesite_sheet').loops(4);
})

ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    Item.of('ashspire:integrated_mechanism').withChance(128.0),
    Item.of('create:zinc_ingot').withChance(0.30),
    Item.of('create:copper_nugget').withChance(0.29),
    Item.of('minecraft:iron_nugget').withChance(0.19),
    Item.of('create:zinc_nugget').withChance(0.08),
    Item.of('minecraft:clock').withChance(0.05)

  ], 'ashspire:zinc_sheet', [
    event.recipes.create.deploying('ashspire:zinc_sheet', ['ashspire:zinc_sheet', 'create:brass_ingot']),
    
    event.recipes.create.deploying('ashspire:zinc_sheet', ['ashspire:zinc_sheet', 'ashspire:polished_spectral_ruby_electron_tube']),
    
    event.recipes.create.deploying('ashspire:zinc_sheet', ['ashspire:zinc_sheet', 'ashspire:integrated_circuit']),
    
    event.recipes.create.deploying('ashspire:zinc_sheet', ['ashspire:zinc_sheet', 'ashspire:steel_gear']),
    
    event.recipes.create.deploying('ashspire:zinc_sheet', ['ashspire:zinc_sheet', 'ashspire:steel_gear'])
    
  ]).transitionalItem('ashspire:zinc_sheet').loops(5);
})

ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    Item.of('ashspire:sealed_mechanism').withChance(128.0),
    Item.of('ashspire:synthetic_rubber_seal').withChance(0.30),
    Item.of('create:copper_nugget').withChance(0.29),
    Item.of('createaddition:electrum_nugget').withChance(0.19),
    Item.of('create:zinc_nugget').withChance(0.08),
    Item.of('minecraft:copper_ingot').withChance(0.05)

  ], 'ashspire:synthetic_rubber', [
    event.recipes.create.deploying('ashspire:synthetic_rubber', ['ashspire:synthetic_rubber', 'ashspire:synthetic_rubber_seal']),
    
    event.recipes.create.deploying('ashspire:synthetic_rubber', ['ashspire:synthetic_rubber', 'ashspire:copper_tube']),
    
    event.recipes.create.deploying('ashspire:synthetic_rubber', ['ashspire:synthetic_rubber', 'createaddition:copper_spool']),
    
    event.recipes.create.deploying('ashspire:synthetic_rubber', ['ashspire:synthetic_rubber', 'createaddition:copper_wire']),
    
    event.recipes.create.deploying('ashspire:synthetic_rubber', ['ashspire:synthetic_rubber', 'ashspire:copper_gear'])
    
    
  ]).transitionalItem('ashspire:synthetic_rubber').loops(5);
})

ServerEvents.recipes(event => {
event.recipes.create.sequenced_assembly([
    Item.of('ashspire:integrated_circuit').withChance(128.0),
    Item.of('createaddition:electrum_nugget').withChance(0.30),
    Item.of('minecraft:gold_nugget').withChance(0.03),
    Item.of('create:brass_nugget').withChance(0.19),
    Item.of('ashspire:plastic_sheet').withChance(0.08),
    Item.of('createaddition:electrum_wire').withChance(0.05)

  ], 'ashspire:plastic_sheet', [
    event.recipes.create.deploying('ashspire:incomplete_integrated_circuit', ['ashspire:incomplete_integrated_circuit', 'createaddition:electrum_nugget']),
    
    event.recipes.create.deploying('ashspire:incomplete_integrated_circuit', ['ashspire:incomplete_integrated_circuit', 'create:brass_nugget']),
    
    event.recipes.create.deploying('ashspire:incomplete_integrated_circuit', ['ashspire:incomplete_integrated_circuit', 'createaddition:electrum_wire']),
    
    event.recipes.create.deploying('ashspire:incomplete_integrated_circuit', ['ashspire:incomplete_integrated_circuit', 'ashspire:lapis_sheet'])
    
    
  ]).transitionalItem('ashspire:incomplete_integrated_circuit').loops(5);
})

