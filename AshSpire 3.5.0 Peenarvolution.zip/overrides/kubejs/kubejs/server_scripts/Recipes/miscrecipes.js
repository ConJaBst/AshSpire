ServerEvents.recipes(event => {
    //All scripts were made by swzo and are borrowed out of Brassworks smp due to some copyright issues, its all fixed dw
  // Recipe Removals
  event.remove({ id: 'create:crushing/tuff' })
  event.remove({ id: 'create:crushing/tuff_recycling' })
  // Add a Create spouting recipe to craft Artifacts' Night Vision Goggles
  event.recipes.createFilling(
    'artifacts:night_vision_goggles',
    [
      'create:goggles',
      Fluid.of('create:potion', 1000, {Bottle:"REGULAR", Potion:"minecraft:night_vision"})
    ]
  );

// Ink Sac from Water, Dried Kelp and Coal (Compacting Recipe)
  event.recipes.createCompacting(
    Item.of('minecraft:ink_sac', 2),
    [
      Fluid.of('minecraft:water', 500),
      'minecraft:dried_kelp',
      'minecraft:coal'
    ]
  )

// Ink Sac from Dried Kelp and Ink (Filling Recipe)
  event.recipes.createFilling(
    Item.of('minecraft:ink_sac', 2),
    [
      'minecraft:dried_kelp',
      Fluid.of('create_enchantment_industry:ink', 500)
    ]
  )


  // Add a Create spouting recipe to craft Artifacts' Night Vision Goggles with Refined Radiance
    event.recipes.create.filling(
    'minecraft:lapis_lazuli',
    [
      'minecraft:blue_dye',
      Fluid.of('create_enchantment_industry:experience', 4) 
    ]
  )
  event.shapeless(
    'minecraft:calcite',
    [
      'create:limestone',
      'minecraft:quartz'
    ]
  )

  // 2 Short Grass → Tall Grass
  event.shapeless(
    'minecraft:tall_grass',
    [
      '2x minecraft:grass' // short grass is just 'minecraft:grass'
    ]
  )

  // Fern Recipe (seeds + short grass)
  event.shapeless(
    'minecraft:fern',
    [
      '#forge:seeds',
      'minecraft:grass'
    ]
  )
  // Large Fern Recipe (2 ferns)
  event.shapeless(
    'minecraft:large_fern',
    [
      '2x minecraft:fern'
    ]
  )

  // Small Dripleaf Recipe (Create compacting)
  event.recipes.create.compacting(
    'minecraft:small_dripleaf',
    [
      'minecraft:clay_ball',
      '#minecraft:leaves',
      Fluid.of('minecraft:water', 100)
    ]
  )

  // Big Dripleaf Recipe (Create compacting)
  event.recipes.create.compacting(
    'minecraft:big_dripleaf',
    [
      'minecraft:small_dripleaf',
      '#minecraft:leaves',
      'minecraft:bone_meal',
      Fluid.of('minecraft:water', 250)
    ]
  )
    event.recipes.create.mixing(
    '2x minecraft:tuff',
    [
      'minecraft:stone',
      'minecraft:cobblestone',
      'minecraft:quartz'
    ])
  // Minecraft: Pointed Dripstone (Create crushing)
  event.recipes.create.crushing([
    '2x minecraft:pointed_dripstone',
    Item.of('minecraft:pointed_dripstone').withChance(0.5)
  ], 'minecraft:dripstone_block')
  
  // Alternative Pointed Dripstone (Create mixing)
  event.recipes.create.mixing(
    'minecraft:pointed_dripstone',
    [
      'minecraft:clay_ball',
      'create:limestone',
      Fluid.of('minecraft:water', 50)
    ]
  )

  // Lily Pad Recipe (Create mixing)
  event.recipes.create.mixing(
    '2x minecraft:lily_pad',
    [
      'minecraft:vine',
      'minecraft:moss_carpet',
      Fluid.of('minecraft:water', 250)
    ]
  )

  // Vines Recipe (Create mixing)
  event.recipes.create.mixing(
    '2x minecraft:vine',
    [
      'minecraft:moss_block',
      '#minecraft:leaves',
      Fluid.of('minecraft:water', 100)
    ]
  )

  // Seagrass Recipe (Create mixing)
  event.recipes.create.mixing(
    '2x minecraft:seagrass',
    [
      'minecraft:grass',
      'minecraft:kelp',
      Fluid.of('minecraft:water', 300)
    ]
  )


  // Rooted Dirt Recipe (Create compacting)
  event.recipes.create.compacting(
    '3x minecraft:rooted_dirt',
    [
      'minecraft:dirt',
      'minecraft:grass_block',
      'minecraft:bone_meal'
    ]
  )

  // Glow Lichen Recipe (Create mixing)
  event.recipes.create.mixing(
    '2x minecraft:glow_lichen',
    [
      'minecraft:vine',
      'minecraft:glow_ink_sac',
      Fluid.of('minecraft:water', 100)
    ]
  )
})