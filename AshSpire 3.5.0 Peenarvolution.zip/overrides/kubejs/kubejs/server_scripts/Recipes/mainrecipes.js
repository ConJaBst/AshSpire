// priority: 0

// Visit the wiki for more info - https://kubejs.com/

    ServerEvents.recipes(event => {
   //Removing recipes
   //Vendor
    event.remove({ output: 'numismatics:vendor'})
    
    event.remove({ output: 'create_connected:copycat_block'})
    
    event.remove({ output: 'create_connected:copycat_slab'})
    
    event.remoge({ output: 'create_new_age:electrical_connector'})
    
    event.remove({ output: 'create_connected:copycat_beam'})
    
    event.remove({ output: 'create_connected:copycat_vertical_step'})
    
    event.remove({ id: 'create_aquatic_ambitions:milling/limestone' })
    
    event.remove({ output: 'create_connected:copycat_stairs'})
    
    event.remove({ output: 'create_connected:copycat_fence'})
    
    event.remove({ output: 'create_connected:copycat_fence_gate'})
    
    event.remove({ output: 'create_connected:copycat_wall'})
    
    event.remove({ output: 'create_connected:copycat_board'})
    
    event.remove({ output: 'create_connected:copycat_box'})
    
    event.remove({ output: 'create_connected:copycat_catwalk'})
    
    event.remove({ type: 'create:pressing', output: 'createaddition:zinc_sheet' });
    
    event.remove({ type: 'create:pressing', output: 'createdeco:zinc_sheet' });
    
    //Bank guide
    event.remove({ output: 'numismatics:banking_guide'})
    //Upgrades
    event.remove({ output: 'sophisticatedbackpacks:stack_upgrade_omega_tier'})
    
    event.remove({ output: 'sophisticatedstorage:stack_upgrade_omega_tier'})
    
    event.remove({ output: 'sophisticatedbackpacks:inception_upgrade'})
    //bug fix
    event.remove({ output: 'brewinandchewin:honey'})
    
    event.remove({ input: 'minecraft:honey_bottle', type: 'create:emptying'})
    
    event.remove({ input: 'minecraft:gilded_blackstone', type: 'create:crushing'})
    //No enchanted apple
    event.remove({ output: 'minecraft:enchanted_golden_apple'})
    //Haunting
    event.recipes.create.haunting("minecraft:coal", "minecraft:charcoal")
    
    event.recipes.create.haunting("3x minecraft:spider_eye", "minecraft:feather")
    
    event.recipes.create.haunting("minecraft:magma_cream", "minecraft:slime_ball")
    
    event.recipes.create.haunting("minecraft:dirt", "minecraft:gravel")
    
    event.recipes.create.haunting([Item.of('minecraft:nether_wart').withChance(0.35)], "minecraft:spider_eye")
    
    event.recipes.create.haunting("2x minecraft:amethyst_shard", "minecraft:flint")
    
    event.recipes.create.haunting([Item.of('minecraft:sea_lantern').withChance(0.25)], "minecraft:ice")
    
    event.recipes.create.haunting([Item.of('minecraft:bone_block').withChance(0.09)], '#minecraft:logs')
    
    event.recipes.create.haunting([Item.of('minecraft:quartz_block').withChance(0.15)], '#minecraft:terracotta')
    //Replace Output/Input
    event.replaceInput({ output: 'createdeco:andesite_bars_overlay' }, 'createdeco:andesite_sheet', 'ashspire:andesite_sheet');
    
    event.replaceInput({ output: 'createdeco:andesite_mesh_fence' }, 'createdeco:andesite_sheet', 'ashspire:andesite_sheet');
    
    event.replaceInput({ output: 'createdeco:andesite_catwalk' }, 'createdeco:andesite_sheet', 'ashspire:andesite_sheet');
    
    event.replaceInput({ output: 'createdeco:andesite_catwalk_railing' }, 'createdeco:andesite_sheet', 'ashspire:andesite_sheet');
    
    event.replaceInput({ output: 'createdeco:andesite_support_wedge' }, 'createdeco:andesite_sheet', 'ashspire:andesite_sheet');
    
    event.replaceInput({ output: 'createdeco:andesite_hull' }, 'createdeco:andesite_sheet', 'ashspire:andesite_sheet');
    
    event.replaceInput({ output: 'createdeco:yellow_andesite_lamp' }, 'createdeco:andesite_sheet', 'ashspire:andesite_sheet');
    
    event.replaceInput({ output: 'createdeco:red_andesite_lamp' }, 'createdeco:andesite_sheet', 'ashspire:andesite_sheet');
    
    event.replaceInput({ output: 'createdeco:green_andesite_lamp' }, 'createdeco:andesite_sheet', 'ashspire:andesite_sheet');
    
    event.replaceInput({ output: 'createdeco:blue_andesite_lamp' }, 'createdeco:andesite_sheet', 'ashspire:andesite_sheet');
    
    event.replaceInput({ output: 'createdeco:andesite_sheet_metal' }, 'createdeco:andesite_sheet', 'ashspire:andesite_sheet');
    
    event.replaceInput({ output: 'minecraft:lodestone' }, 'minecraft:netherite_ingot', 'minecrsft:iron_ingot');
    
    //Smokeing n splashing
    event.smoking("minecraft:leather", "minecraft:rotten_flesh")
    
    event.recipes.create.splashing([Item.of('minecraft:clay_ball').withChance(0.95)], 'minecraft:dirt')
    //Spouting
    event.recipes.createFilling('4x minecraft:end_stone',['minecraft:cobblestone', Fluid.of('create:potion', 250, {Bottle:"REGULAR", Potion:"minecraft:slow_falling"})])
    
    event.recipes.createFilling('2x minecraft:pearlescent_froglight',['minecraft:slime_block', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:invisibility"})])
    
    event.recipes.createFilling('2x minecraft:verdant_froglight',['minecraft:slime_block', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:poison"})])
    
    event.recipes.createFilling('2x minecraft:ochre_froglight',['minecraft:slime_block', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:leaping"})])
    
    event.recipes.createFilling('2x minecraft:feather',['minecraft:ink_sac', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:swiftness"})])
    
    event.recipes.createFilling('minecraft:warped_nylium',['minecraft:netherrack', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:swiftness"})])
    
    event.recipes.createFilling('minecraft:crimson_nylium',['minecraft:netherrack', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:healing"})])
    
    event.recipes.createFilling('minecraft:mycelium',['minecraft:dirt', Fluid.of('create:potion', 250, {Bottle:"REGULAR", Potion:"minecraft:slowness"})])
    
    event.recipes.createFilling('minecraft:rotten_flesh',['#ashspire:raw_meat_spire', Fluid.of('create:potion', 250, {Bottle:"REGULAR", Potion:"minecraft:poison"})])
    
    event.recipes.createFilling('2x minecraft:shroomlight',['#ashspire:mushroom_blocks', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:night_vision"})])
    
    event.recipes.createFilling('minecraft:slime_ball',['minecraft:magma_cream', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:poison"})])
    
    event.recipes.createFilling('minecraft:flowering_azalea',['minecraft:azalea', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:regeneration"})])
    
    event.recipes.createFilling('4x minecraft:flowering_azalea_leaves',['minecraft:azalea_leaves', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:regeneration"})])
    
    event.recipes.createFilling('minecraft:azalea_leaves',['#minecraft:leaves', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:healing"})])
    
    event.recipes.createFilling('minecraft:azalea',['#minecraft:saplings', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:healing"})])
    
    event.recipes.createFilling('minecraft:dark_prismarine',['minecraft:prismarine', Fluid.of('create_enchantment_industry:ink', 100)])
    //Pressing
    event.recipes.create.pressing('ashspire:zinc_sheet', 'create:zinc_ingot')
    
    event.recipes.create.pressing('ashspire:andesite_sheet', 'create:andesite_alloy')
    
    event.recipes.create.pressing('ashspire:steel_sheet', 'ashspire:steel_ingot')
    
    event.recipes.create.pressing('ashspire:lapis_sheet', 'ashspire:lapis_alloy')
    
    //Polishing
    event.recipes.create.sandpaper_polishing('ashspire:polished_spectral_ruby', 'ashspire:spectral_ruby')
    
    //Compacting
    event.recipes.create.compacting('minecraft:calcite', ['2x minecraft:bone_meal', 'minecraft:cobblestone', Fluid.of(('minecraft:water'), 250)])
    
    event.recipes.create.compacting('4x minecraft:tuff', ['16x minecraft:cobblestone', Fluid.of(('minecraft:water'), 250)])
    
    event.recipes.create.compacting('2x minecraft:redstone', ['minecraft:flint', 'minecraft:netherrack', Fluid.of(('minecraft:lava'), 250)])
    event.recipes.create.compacting('minecraft:blaze_rod', ['6x minecraft:blaze_powder', Fluid.of(('minecraft:lava'), 500)])
    
    event.recipes.create.compacting('minecraft:red_mushroom_block', ['4x minecraft:red_mushroom'])
    
    event.recipes.create.compacting('minecraft:brown_mushroom_block', ['4x minecraft:brown_mushroom'])
    
    event.recipes.create.compacting('minecraft:mushroom_stem', ['2x minecraft:brown_mushroom_block', '2x minecraft:red_mushroom_block', '2x bone_meal'])
    //Emptying
    event.recipes.create.emptying(['minecraft:glass_bottle', Fluid.of('create:honey', 250)], 'minecraft:honey_bottle')
    //Crushing
    event.recipes.create.crushing([Item.of("minecraft:magma_cream").withChance(0.35), Item.of("minecraft:blaze_powder").withChance(0.25)], "minecraft:basalt")
    
    event.recipes.create.crushing([Item.of("ashspire:crushed_limestone"), Item.of("ashspire:crushed_limestone").withChance(0.25)], "create:limestone")
    
    event.recipes.create.crushing([Item.of("create_aquatic_ambitions:calcium_rich_powder"), Item.of("create_aquatic_ambitions:calcium_rich_powder").withChance(0.50), Item.of("create_aquatic_ambitions:suspicious_rock").withChance(0.05)], "ashspire:crushed_limestone")
    
    event.recipes.create.crushing([Item.of("2x minecraft:glowstone_dust").withChance(0.20)],'minecraft:soul_sand')
    
    event.recipes.create.crushing([Item.of("create:experience_nugget").withChance(0.45)],'minecraft:quartz')
    
    event.recipes.create.crushing([Item.of("minecraft:quartz").withChance(0.80), Item.of("minecraft:blaze_powder").withChance(0.20)], 'create:scoria')
    
    event.recipes.create.crushing([Item.of("create:crushed_raw_gold").withChance(0.02), Item.of("minecraft:quartz").withChance(0.12), Item.of("minecraft:coal").withChance(0.25)], 'create:scorchia')
    
    event.recipes.create.crushing([Item.of("2x minecraft:gold_nugget").withChance(0.12), Item.of("minecraft:quartz").withChance(0.09), Item.of("minecraft:coal").withChance(0.25)], 'minecraft:blackstone')
    
    event.recipes.create.crushing([Item.of("2x minecraft:mangrove_propagule").withChance(0.40), Item.of("minecraft:mangrove_propagule").withChance(0.70)], 'minecraft:mangrove_roots')
    
    event.recipes.create.crushing([Item.of("2x create:rose_quartz").withChance(0.25), Item.of("minecraft:netherrack").withChance(0.60), Item.of("2x create:cinder_flour").withChance(0.54)], 'minecraft:crimson_nylium')
    
    event.recipes.create.crushing([Item.of("minecraft:ender_pearl").withChance(0.25)], 'minecraft:end_stone')
    
    event.recipes.create.crushing([Item.of("minecraft:ender_pearl").withChance(0.15), Item.of("minecraft:netherrack").withChance(0.60), Item.of("2x create:cinder_flour").withChance(0.54)], 'minecraft:warped_nylium')
    
    //Deploying
    event.recipes.create.deploying('artifacts:pocket_piston', ['minecraft:piston', 'create:piston_extension_pole'])
    
    event.recipes.create.deploying('ashspire:cuhcat_mold', ['create:iron_sheet', 'minecraft:iron_axe']).keepHeldItem()
    
    event.recipes.create.deploying('ashspire:raw_cuhcat_nugget', ['#forge:raw_chicken', 'ashspire:cuhcat_mold']).keepHeldItem()
    
    //Mixing
    event.recipes.create.mixing('ashspire:cuhcat_nugget', ["ashspire:raw_cuhcat_nugget", "2x minecraft:blaze_powder", "2x minecraft:orange_dye", Fluid.of(("create:honey"), 250), Fluid.of(("create_bic_bit:frying_oil"), 1000)]).heated()
    
    event.recipes.create.mixing([Fluid.of('ashspire:processed_logic', 125)], ["minecraft:ender_pearl", "2x minecraft:blaze_powder", "3x create:rose_quartz", "4x create:crushed_raw_zinc", Fluid.of(("ashspire:raw_logic"), 1000), Fluid.of(("create_central_kitchen:apple_cider"), 250)]).superheated()
    
    event.recipes.create.mixing('ashspire:plastic_sheet', ["ashspire:coke", "create:pulp", Fluid.of(('createaddition:bioethanol'), 250)]).superheated()
    
    event.recipes.create.mixing('2x minecraft:netherrack', ["minecraft:andesite", "minecraft:nether_wart"]).heated()
    
    event.recipes.create.mixing('ashspire:coke', ["#minecraft:coals"]).heated()
    
    event.recipes.create.mixing('4x minecraft:phantom_membrane', ["2x minecraft:feather", "2x minecraft:gunpowder", "2x minecraft:purple_dye"]).superheated()
    
    event.recipes.create.mixing('2x minecraft:gunpowder', ["2x create:cinder_flour", "2x minecraft:charcoal", "create_aquatic_ambitions:calcium_rich_powder"])
    
    event.recipes.create.mixing([Fluid.of('create:honey', 250)], ['6x minecraft:honeycomb']).heated()
    
    event.recipes.create.mixing('2x minecraft:dripstone_block', ["minecraft:calcite", Fluid.water(250)])
    
    event.recipes.create.mixing('2x create:asurine', ["3x minecraft:clay_ball", "3x minecraft:flint", Fluid.water(250)])
    
    event.recipes.create.mixing('2x create:veridium', ["3x minecraft:clay_ball", "3x minecraft:flint", Fluid.lava(250)])
    
    event.recipes.create.mixing('2x create:crimsite', ["4x minecraft:cobblestone", "4x minecraft:flint", Fluid.lava(250)])
    
    event.recipes.create.mixing('2x create:ochrum', ["4x minecraft:sand", "3x minecraft:clay_ball", Fluid.lava(250)])
    
    event.recipes.create.mixing('4x minecraft:gilded_blackstone', ["2x minecraft:gold_nugget", "minecraft:blackstone"]).heated()
    
    event.recipes.create.mixing('4x minecraft:moss_block', ["2x #forge:seeds", "#minecraft:leaves"])
    
    event.recipes.create.mixing(['minecraft:fishing_rod', 'minecraft:sand', Item.of("minecraft:cod").withChance(0.45), Item.of("minecraft:salmon").withChance(0.45)], ["minecraft:sand", "minecraft:fishing_rod", "10x minecraft:kelp", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of('4x minecraft:clay_ball').withChance(0.65),Item.of('2x minecraft:clay_ball').withChance(0.85), Item.of('4x minecraft:blue_dye').withChance(0.75), Item.of('2x minecraft:light_blue_dye').withChance(0.55)], ["minecraft:honeycomb", "2x minecraft:lapis_lazuli", Fluid.water(500)]).heated()
    
    event.recipes.create.mixing([Fluid.of('ashspire:raw_logic', 250)], ["8x create:andesite_alloy", "2x create:brass_ingot", "create:goggles", '3x create:precision_mechanism']).superheated()
    
    event.recipes.create.mixing('3x culturaldelights:corn_dough', ["3x culturaldelights:corn_cob", Fluid.water(250)])
    
    event.recipes.create.mixing('minecraft:crying_obsidian', ["farmersdelight:onion", "minecraft:obsidian"])
    
    event.recipes.create.mixing('minecraft:crying_obsidian', ["2x minecraft:amethyst_shard", "minecraft:obsidian"])
    
    event.recipes.create.mixing('minecraft:podzol', ["2x minecraft:mud", "minecraft:dirt"])
    //Speed Mixing
    event.recipes.create.mixing('2x create:andesite_alloy', ["2x minecraft:iron_nugget", "2x minecraft:andesite"]).heated()
    
    event.recipes.create.mixing('2x create:andesite_alloy', ["2x create:zinc_nugget", "2x minecraft:andesite"]).heated()
    
    event.recipes.create.mixing('8x create:andesite_alloy', ["8x minecraft:iron_nugget", "8x minecraft:andesite"]).superheated()
    
    event.recipes.create.mixing('8x create:andesite_alloy', ["8x create:zinc_nugget", "8x minecraft:andesite"]).superheated()
    //Cuhpsicle Only Recipe 
    event.recipes.create.mixing([Item.of("2x ashspire:cuhpsicle"), Item.of("ashspire:cuhcat_mold")], ["2x minecraft:ice", "minecraft:stick", "2x minecraft:sugar", "2x minecraft:gray_dye", "ashspire:cuhcat_mold", Fluid.of(("create:chocolate"), 250)])
    
    event.recipes.create.mixing([Item.of("ashspire:steel_nugget")], ["minecraft:flint", "ashspire:coke", "ashspire:crushed_limestone", "minecraft:iron_nugget", Fluid.of(('createaddition:bioethanol'), '250')]).superheated()
    
    event.recipes.create.mixing([Item.of("ashspire:synthetic_rubber")], ["2x create:pulp", "createaddition:copper_wire", Fluid.of(('createaddition:seed_oil'), 750)])
    
})
ServerEvents.recipes(event => {
    //Flower Recipes
    event.recipes.create.mixing([Item.of("2x minecraft:poppy"), Item.of("minecraft:poppy").withChance(0.45)], ["minecraft:poppy", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:dandelion"), Item.of("minecraft:dandelion").withChance(0.45)], ["minecraft:dandelion", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:lily_of_the_valley"), Item.of("minecraft:lily_of_the_valley").withChance(0.45)], ["minecraft:lily_of_the_valley", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:cornflower"), Item.of("minecraft:cornflower").withChance(0.45)], ["minecraft:cornflower", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:blue_orchid"), Item.of("minecraft:blue_orchid").withChance(0.45)], ["minecraft:blue_orchid", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:allium"), Item.of("minecraft:allium").withChance(0.45)], ["minecraft:allium", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:pitcher_plant"), Item.of("minecraft:pitcher_plant").withChance(0.45)], ["minecraft:pitcher_plant", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:torchflower"), Item.of("minecraft:torchflower").withChance(0.45)], ["minecraft:torchflower", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:azure_bluet"), Item.of("minecraft:azure_bluet").withChance(0.45)], ["minecraft:azure_bluet", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:red_tulip"), Item.of("minecraft:red_tulip").withChance(0.45)], ["minecraft:red_tulip", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:orange_tulip"), Item.of("minecraft:orange_tulip").withChance(0.45)], ["minecraft:orange_tulip", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:white_tulip"), Item.of("minecraft:white_tulip").withChance(0.45)], ["minecraft:white_tulip", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:pink_tulip"), Item.of("minecraft:pink_tulip").withChance(0.45)], ["minecraft:pink_tulip", "2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:oxeye_daisy"), Item.of("minecraft:oxeye_daisy").withChance(0.45)], ["minecraft:oxeye_daisy","2x minecraft:bone_meal", Fluid.water(1000)])
    
    event.recipes.create.mixing([Item.of("2x minecraft:wither_rose"), Item.of("minecraft:wither_rose").withChance(0.45)], ["minecraft:wither_rose", "2x minecraft:bone_meal", Fluid.lava(1000)])
    
    event.recipes.create.mixing([Item.of("minecraft:sunflower")], ["2x minecraft:dandelion", "2x minecraft:vine", Fluid.water(1000)])
})

ServerEvents.recipes(event => {
    //Ore Mixing
    event.recipes.create.mixing('minecraft:coal_ore', ["24x minecraft:coal", "minecraft:stone"])
    
    event.recipes.create.mixing('minecraft:iron_ore', ["12x create:crushed_raw_iron", "minecraft:stone"])
    
    event.recipes.create.mixing('minecraft:copper_ore', ["32x create:crushed_raw_copper", "minecraft:stone"])
    
    event.recipes.create.mixing('minecraft:gold_ore', ["12x create:crushed_raw_gold", "minecraft:stone"])
    
    event.recipes.create.mixing('minecraft:diamond_ore', ["12x minecraft:diamond", "minecraft:stone"])
    
    event.recipes.create.mixing('minecraft:lapis_ore', ["24x minecraft:lapis_lazuli", "minecraft:stone"])
    
    event.recipes.create.mixing('minecraft:emerald_ore', ["12x minecraft:emerald", "minecraft:stone"])
    
    event.recipes.create.mixing('minecraft:redstone_ore', ["12x minecraft:redstone", "minecraft:stone"])
    
    event.recipes.create.mixing('create:zinc_ore', ["12x create:crushed_raw_zinc", "minecraft:stone"])
    
    event.recipes.create.mixing('minecraft:deepslate_coal_ore', ["24x minecraft:coal", "minecraft:deepslate"])
    
    event.recipes.create.mixing('minecraft:deepslate_iron_ore', ["12x create:crushed_raw_iron", "minecraft:deepslate"])
    
    event.recipes.create.mixing('minecraft:deepslate_copper_ore', ["32x create:crushed_raw_copper", "minecraft:deepslate"])
    
    event.recipes.create.mixing('minecraft:deepslate_gold_ore', ["12x create:crushed_raw_gold", "minecraft:deepslate"])
    
    event.recipes.create.mixing('minecraft:deepslate_diamond_ore', ["12x minecraft:diamond", "minecraft:deepslate"])
    
    event.recipes.create.mixing('minecraft:deepslate_lapis_ore', ["24x minecraft:lapis_lazuli", "minecraft:deepslate"])
    
    event.recipes.create.mixing('minecraft:deepslate_emerald_ore', ["12x minecraft:emerald", "minecraft:deepslate"])
    
    event.recipes.create.mixing('minecraft:deepslate_redstone_ore', ["12x minecraft:redstone", "minecraft:deepslate"])
    
    event.recipes.create.mixing('create:deepslate_zinc_ore', ["12x create:crushed_raw_zinc", "minecraft:deepslate"])
    
    event.recipes.create.mixing('minecraft:ancient_debris', ["4x minecraft:netherite_scrap", "2x minecraft:netherrack", Fluid.lava(1000)])
})

ServerEvents.recipes(event => {
   
event.custom({
  type: 'create_new_age:energising',
  energy_needed: 15000,
  ingredients: [{
    item: 'minecraft:iron_ore',
    }],
  results: [{
    item: 'create_new_age:magnetite_block',
  }] 
})

event.custom({
  type: 'create_new_age:energising',
  energy_needed: 1500,
  ingredients: [{
    item: 'create_aquatic_ambitions:calcium_rich_powder',
    }],
  results: [{
    item: 'minecraft:redstone',
  }] 
})

event.custom({
  type: 'create_new_age:energising',
  energy_needed: 180000,
  ingredients: [{
    item: 'minecraft:quartz_block',
    }],
  results: [{
    item: 'create:experience_block',
  }] 
})

    event.custom({
    type: 'createaddition:rolling',
    input: {
      item: 'ashspire:steel_ingot'
    },
    result: {
      item: 'ashspire:steel_rod',
      count: 2
    }
  })
})
//Vanilla Recipes
ServerEvents.recipes(event => {
//Crafting
event.shaped('minecraft:saddle', [
    ' L ',
    'LIL'
  ], {
    I: 'minecraft:iron_ingot',
    L: 'minecraft:leather'})
    
    event.shaped('ashspire:spectral_ruby', [
    'AGG',
    'GGG',
    'GGG'
  ], {
    A: 'minecraft:amethyst_shard',
    G: 'minecraft:glowstone_dust'
  })
  
    event.shaped('ashspire:steel_ingot', [
    'SSS',
    'SSS',
    'SSS'
  ], {
    S: 'ashspire:steel_nugget'
  })
    
    event.shaped('ashspire:polished_spectral_ruby_electron_tube', [
    ' L ',
    ' I '
  ], {
    L: 'ashspire:polished_spectral_ruby',
    I: 'ashspire:steel_sheet'
  })
    
    event.shaped('ashspire:steel_gear', [
    ' L ',
    'LIL',
    ' L '
  ], {
    I: 'create:shaft',
    L: 'ashspire:steel_sheet'
  })
    
    event.shaped('ashspire:andesite_gear', [
    ' L ',
    'LIL',
    ' L '
  ], {
    I: 'create:shaft',
    L: 'ashspire:andesite_sheet'
  })
    
    event.shaped('ashspire:copper_gear', [
    ' L ',
    'LIL',
    ' L '
  ], {
    I: 'create:shaft',
    L: 'create:copper_sheet'
    })
    
    event.shaped('ashspire:electrum_gear', [
    ' L ',
    'LIL',
    ' L '
  ], {
    I: 'create:shaft',
    L: 'createaddition:electrum_sheet'
  })
    
    event.shaped('ashspire:synthetic_rubber_seal', [
    'LLL',
    'L L',
    'LLL'
  ], {
    L: 'ashspire:synthetic_rubber'
  })
    
    
    event.shaped('ashspire:copper_tube', [
    ' L ',
    ' I ',
    ' L '
  ], {
    I: '#forge:glass',
    L: 'create:copper_sheet'
  })
    
    event.shaped('ashspire:lapis_alloy', [
    'IL',
    'LI',
  ], {
    I: 'minecraft:lapis_lazuli',
    L: 'create:zinc_nugget'
  })
})