StartupEvents.registry('fluid', event => { 
event.create('ashspire:raw_logic')
    .displayName('Unprocessed Liquefied Logic')
    .stillTexture('ashspire:block/fluids/number_still')
    .flowingTexture('ashspire:block/fluids/number_flow')
    .color(0xE7FFCB)
    .bucketColor(0xE7FFCB)
})

StartupEvents.registry('fluid', event => { 
event.create('ashspire:processed_logic')
    .displayName('Liquefied Logic')
    .stillTexture('ashspire:block/fluids/matrix_still')
    .flowingTexture('ashspire:block/fluids/matrix_flow')
    .bucketColor(0xC8FF4C)
})
