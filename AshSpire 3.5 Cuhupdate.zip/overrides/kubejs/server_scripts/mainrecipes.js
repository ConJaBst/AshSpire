// priority: 0

// Visit the wiki for more info - https://kubejs.com/

    ServerEvents.recipes(event => {
   //Removing recipes
   //Vendor
    event.remove({ output: 'numismatics:vendor'})
    //Bank guide
    event.remove({ output: 'numismatics:banking_guide'})
    //Upgrades
    event.remove({ output: 'sophisticatedbackpacks:stack_upgrade_omega_tier'})
    event.remove({ output: 'sophisticatedstorage:stack_upgrade_omega_tier'})
    event.remove({ output: 'sophisticatedbackpacks:inception_upgrade'})
    //bug fix
    event.remove({ output: 'brewinandchewin:honey'})
    event.remove({ input: 'minecraft:honey_bottle', type: 'create:emptying'})
    event.remove({ input: 'minecraft:gilded_blackstone', type: 'create:crushing'})
    //No enchanted apple
    event.remove({ output: 'minecraft:enchanted_golden_apple'})
    //Haunting
    event.recipes.create.haunting("minecraft:coal", "minecraft:charcoal")
    event.recipes.create.haunting("3x minecraft:spider_eye", "minecraft:feather")
    event.recipes.create.haunting("minecraft:magma_cream", "minecraft:slime_ball")
    event.recipes.create.haunting("minecraft:dirt", "minecraft:gravel")
    event.recipes.create.haunting([Item.of('minecraft:nether_wart').withChance(0.35)], "minecraft:spider_eye")
    event.recipes.create.haunting("2x minecraft:amethyst_shard", "minecraft:flint")
    event.recipes.create.haunting([Item.of('minecraft:sea_lantern').withChance(0.25)], "minecraft:ice")
    event.recipes.create.haunting([Item.of('minecraft:bone_block').withChance(0.09)], '#minecraft:logs')
    event.recipes.create.haunting([Item.of('minecraft:quartz_block').withChance(0.15)], '#minecraft:terracotta')
    //Smokeing n splashing
    event.smoking("minecraft:leather", "minecraft:rotten_flesh")
    event.recipes.create.splashing([Item.of('minecraft:clay_ball').withChance(0.95)], 'minecraft:dirt')
    //Spouting
    event.recipes.createFilling('4x minecraft:end_stone',['minecraft:cobblestone', Fluid.of('create:potion', 250, {Bottle:"REGULAR", Potion:"minecraft:slow_falling"})])
    event.recipes.createFilling('2x minecraft:pearlescent_froglight',['minecraft:slime_block', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:slow_falling"})])
    event.recipes.createFilling('2x minecraft:verdant_froglight',['minecraft:slime_block', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:poison"})])
    event.recipes.createFilling('2x minecraft:ochre_froglight',['minecraft:slime_block', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:fire_resistance"})])
    event.recipes.createFilling('2x minecraft:feather',['minecraft:ink_sac', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:swiftness"})])
    event.recipes.createFilling('minecraft:warped_nylium',['minecraft:netherrack', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:swiftness"})])
    event.recipes.createFilling('minecraft:crimson_nylium',['minecraft:netherrack', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:healing"})])
    event.recipes.createFilling('minecraft:mycelium',['minecraft:dirt', Fluid.of('create:potion', 250, {Bottle:"REGULAR", Potion:"minecraft:slowness"})])
    event.recipes.createFilling('minecraft:rotten_flesh',['#ashspire:raw_meat_spire', Fluid.of('create:potion', 250, {Bottle:"REGULAR", Potion:"minecraft:poison"})])
    event.recipes.createFilling('2x minecraft:shroomlight',['#ashspire:mushroom_blocks', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:night_vision"})])
    event.recipes.createFilling('minecraft:slime_ball',['minecraft:magma_cream', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:poison"})])
    event.recipes.createFilling('minecraft:flowering_azalea',['minecraft:azalea', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:regeneration"})])
    event.recipes.createFilling('4x minecraft:flowering_azalea_leaves',['minecraft:azalea_leaves', Fluid.of('create:potion', 125, {Bottle:"REGULAR", Potion:"minecraft:regeneration"})])
    //Compacting
    event.recipes.create.compacting('minecraft:calcite', ['2x minecraft:bone_meal', 'minecraft:cobblestone', Fluid.of(('minecraft:water'), 250)])
    event.recipes.create.compacting('4x minecraft:tuff', ['16x minecraft:cobblestone', Fluid.of(('minecraft:water'), 250)])
    event.recipes.create.compacting('2x minecraft:redstone', ['minecraft:flint', 'minecraft:netherrack', Fluid.of(('minecraft:lava'), 250)])
    event.recipes.create.compacting('minecraft:blaze_rod', ['6x minecraft:blaze_powder', Fluid.of(('minecraft:lava'), 500)])
    event.recipes.create.compacting('minecraft:red_mushroom_block', ['4x minecraft:red_mushroom'])
    event.recipes.create.compacting('minecraft:brown_mushroom_block', ['4x minecraft:brown_mushroom'])
    //Emptying
    event.recipes.create.emptying(['minecraft:glass_bottle', Fluid.of('create:honey', 250)], 'minecraft:honey_bottle')
    //Crushing
    event.recipes.create.crushing([Item.of("minecraft:magma_cream").withChance(0.35), Item.of("minecraft:blaze_powder").withChance(0.25)], "minecraft:basalt")
    event.recipes.create.crushing([Item.of("2x minecraft:glowstone_dust").withChance(0.20)],'minecraft:soul_sand')
    event.recipes.create.crushing([Item.of("create:experience_nugget").withChance(0.45)],'minecraft:quartz')
    event.recipes.create.crushing([Item.of("minecraft:quartz").withChance(0.80), Item.of("minecraft:blaze_powder").withChance(0.20)], 'create:scoria')
    event.recipes.create.crushing([Item.of("create:crushed_raw_gold").withChance(0.02), Item.of("minecraft:quartz").withChance(0.12), Item.of("minecraft:coal").withChance(0.25)], 'create:scorchia')
    event.recipes.create.crushing([Item.of("2x minecraft:gold_nugget").withChance(0.12), Item.of("minecraft:quartz").withChance(0.09), Item.of("minecraft:coal").withChance(0.25)], 'minecraft:blackstone')
    event.recipes.create.crushing([Item.of("2x minecraft:mangrove_propagule").withChance(0.40), Item.of("minecraft:mangrove_propagule").withChance(0.70)], 'minecraft:mangrove_roots')
    event.recipes.create.crushing([Item.of("2x create:rose_quartz").withChance(0.25), Item.of("minecraft:netherrack").withChance(0.60), Item.of("2x create:cinder_flour").withChance(0.54)], 'minecraft:crimson_nylium')
    event.recipes.create.crushing([Item.of("minecraft:ender_pearl").withChance(0.25)], 'minecraft:end_stone')
    event.recipes.create.crushing([Item.of("minecraft:ender_pearl").withChance(0.15), Item.of("minecraft:netherrack").withChance(0.60), Item.of("2x create:cinder_flour").withChance(0.54)], 'minecraft:warped_nylium')
    //Mixing
    event.recipes.create.mixing('2x minecraft:netherrack', ["minecraft:andesite", "minecraft:nether_wart"]).heated()
    event.recipes.create.mixing('4x minecraft:phantom_membrane', ["2x minecraft:feather", "2x minecraft:gunpowder", "2x minecraft:purple_dye"]).superheated()
    event.recipes.create.mixing('4x minecraft:gunpowder', ["2x create:cinder_flour", "2x minecraft:charcoal", "minecraft:bone_meal"])
    event.recipes.create.mixing('2x minecraft:dripstone_block', ["minecraft:calcite", Fluid.water(250)])
    event.recipes.create.mixing('2x create:asurine', ["3x minecraft:clay_ball", "3x minecraft:flint", Fluid.water(250)])
    event.recipes.create.mixing('2x create:veridium', ["3x minecraft:clay_ball", "3x minecraft:flint", Fluid.lava(250)])
    event.recipes.create.mixing('2x create:crimsite', ["4x minecraft:cobblestone", "4x minecraft:flint", Fluid.lava(250)])
    event.recipes.create.mixing('2x create:ochrum', ["4x minecraft:sand", "3x minecraft:clay_ball", Fluid.lava(250)])
    event.recipes.create.mixing('4x minecraft:gilded_blackstone', ["2x minecraft:gold_nugget", "minecraft:blackstone"]).heated()
    event.recipes.create.mixing('4x minecraft:moss_block', ["2x #forge:seeds", "#minecraft:leaves"])
    event.recipes.create.mixing(['minecraft:fishing_rod', 'minecraft:sand', Item.of("minecraft:cod").withChance(0.45), Item.of("minecraft:salmon").withChance(0.45)], ["minecraft:sand", "minecraft:fishing_rod", "10x minecraft:kelp", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of('4x minecraft:clay_ball').withChance(0.65),Item.of('2x minecraft:clay_ball').withChance(0.85), Item.of('4x minecraft:blue_dye').withChance(0.75), Item.of('2x minecraft:light_blue_dye').withChance(0.55)], ["minecraft:honeycomb", "2x minecraft:lapis_lazuli", Fluid.water(500)]).heated()
    event.recipes.create.mixing('culturaldelights:corn_dough', ["3x culturaldelights:corn_cob", Fluid.water(250)])
    event.recipes.create.mixing('minecraft:crying_obsidian', ["farmersdelight:onion", "minecraft:obsidian"])
    event.recipes.create.mixing('minecraft:crying_obsidian', ["2x minecraft:amethyst_shard", "minecraft:obsidian"])
    event.recipes.create.mixing('minecraft:podzol', ["2x minecraft:mud", "minecraft:dirt"])
    event.recipes.create.mixing('minecraft:azalea_leaves', ["2x minecraft:moss_block", "#minecraft:leaves"])
    event.recipes.create.mixing('minecraft:azalea', ["2x minecraft:moss_block", "#minecraft:saplings"])
    //Speed Mixing
    event.recipes.create.mixing('2x create:andesite_alloy', ["2x minecraft:iron_nugget", "2x minecraft:andesite"]).heated()
    event.recipes.create.mixing('2x create:andesite_alloy', ["2x create:zinc_nugget", "2x minecraft:andesite"]).heated()
    event.recipes.create.mixing('8x create:andesite_alloy', ["8x minecraft:iron_nugget", "8x minecraft:andesite"]).superheated()
    event.recipes.create.mixing('8x create:andesite_alloy', ["8x create:zinc_nugget", "8x minecraft:andesite"]).superheated()
    //Cuhpsicle Only Recipe 
    event.recipes.create.mixing('4x ashspire:cuhpsicle', ["2x minecraft:ice", "minecraft:stick", "2x minecraft:sugar", "2x minecraft:gray_dye", Fluid.of(("create:chocolate"), 250)])
})
ServerEvents.recipes(event => {
    //Flower Recipes
    event.recipes.create.mixing([Item.of("2x minecraft:poppy"), Item.of("minecraft:poppy").withChance(0.45)], ["minecraft:poppy", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:dandelion"), Item.of("minecraft:dandelion").withChance(0.45)], ["minecraft:dandelion", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:lily_of_the_valley"), Item.of("minecraft:lily_of_the_valley").withChance(0.45)], ["minecraft:lily_of_the_valley", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:cornflower"), Item.of("minecraft:cornflower").withChance(0.45)], ["minecraft:cornflower", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:blue_orchid"), Item.of("minecraft:blue_orchid").withChance(0.45)], ["minecraft:blue_orchid", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:allium"), Item.of("minecraft:allium").withChance(0.45)], ["minecraft:allium", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:pitcher_plant"), Item.of("minecraft:pitcher_plant").withChance(0.45)], ["minecraft:pitcher_plant", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:torchflower"), Item.of("minecraft:torchflower").withChance(0.45)], ["minecraft:torchflower", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:azure_bluet"), Item.of("minecraft:azure_bluet").withChance(0.45)], ["minecraft:azure_bluet", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:red_tulip"), Item.of("minecraft:red_tulip").withChance(0.45)], ["minecraft:red_tulip", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:orange_tulip"), Item.of("minecraft:orange_tulip").withChance(0.45)], ["minecraft:orange_tulip", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:white_tulip"), Item.of("minecraft:white_tulip").withChance(0.45)], ["minecraft:white_tulip", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:pink_tulip"), Item.of("minecraft:pink_tulip").withChance(0.45)], ["minecraft:pink_tulip", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:oxeye_daisy"), Item.of("minecraft:oxeye_daisy").withChance(0.45)], ["minecraft:oxeye_daisy", Fluid.water(1000)])
    event.recipes.create.mixing([Item.of("2x minecraft:wither_rose"), Item.of("minecraft:wither_rose").withChance(0.45)], ["minecraft:wither_rose", Fluid.lava(1000)])
})

ServerEvents.recipes(event => {
    //Ore Mixing
    event.recipes.create.mixing('minecraft:coal_ore', ["24x minecraft:coal", "minecraft:stone"])
    event.recipes.create.mixing('minecraft:iron_ore', ["12x create:crushed_raw_iron", "minecraft:stone"])
    event.recipes.create.mixing('minecraft:copper_ore', ["32x create:crushed_raw_copper", "minecraft:stone"])
    event.recipes.create.mixing('minecraft:gold_ore', ["12x create:crushed_raw_gold", "minecraft:stone"])
    event.recipes.create.mixing('minecraft:diamond_ore', ["12x minecraft:diamond", "minecraft:stone"])
    event.recipes.create.mixing('minecraft:lapis_ore', ["24x minecraft:lapis_lazuli", "minecraft:stone"])
    event.recipes.create.mixing('minecraft:emerald_ore', ["12x minecraft:emerald", "minecraft:stone"])
    event.recipes.create.mixing('minecraft:redstone_ore', ["12x minecraft:redstone", "minecraft:stone"])
    event.recipes.create.mixing('minecraft:deepslate_coal_ore', ["24x minecraft:coal", "minecraft:deepslate"])
    event.recipes.create.mixing('minecraft:deepslate_iron_ore', ["12x create:crushed_raw_iron", "minecraft:deepslate"])
    event.recipes.create.mixing('minecraft:deepslate_copper_ore', ["32x create:crushed_raw_copper", "minecraft:deepslate"])
    event.recipes.create.mixing('minecraft:deepslate_gold_ore', ["12x create:crushed_raw_gold", "minecraft:deepslate"])
    event.recipes.create.mixing('minecraft:deepslate_diamond_ore', ["12x minecraft:diamond", "minecraft:deepslate"])
    event.recipes.create.mixing('minecraft:deepslate_lapis_ore', ["24x minecraft:lapis_lazuli", "minecraft:deepslate"])
    event.recipes.create.mixing('minecraft:deepslate_emerald_ore', ["12x minecraft:emerald", "minecraft:deepslate"])
    event.recipes.create.mixing('minecraft:deepslate_redstone_ore', ["12x minecraft:redstone", "minecraft:deepslate"])
    event.recipes.create.mixing('minecraft:ancient_debris', ["4x minecraft:netherite_scrap", "2x minecraft:netherrack", Fluid.lava(1000)])
})

ServerEvents.recipes(event => {
   
event.custom({
  type: 'create_new_age:energising',
  energy_needed: 15000,
  ingredients: [{
    item: 'minecraft:iron_ore',
    }],
  results: [{
    item: 'create_new_age:magnetite_block',
  }] 
})

event.custom({
  type: 'create_new_age:energising',
  energy_needed: 5000,
  ingredients: [{
    item: 'minecraft:sand',
    }],
  results: [{
    item: 'minecraft:redstone',
  }] 
})

event.custom({
  type: 'create_new_age:energising',
  energy_needed: 50000,
  ingredients: [{
    item: 'minecraft:quartz_block',
    }],
  results: [{
    item: 'create:experience_block',
  }] 
})
})