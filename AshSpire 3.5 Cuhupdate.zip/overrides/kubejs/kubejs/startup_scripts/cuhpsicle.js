StartupEvents.registry('item', event => { 
    event.create('ashspire:cuhpsicle').food(food => {
    food
    .hunger(8)
    .saturation(1)
    .removeEffect('minecraft:poison')
    .alwaysEdible()
    .fastToEat()
    })
})

StartupEvents.registry('item', event => { 
    event.create('ashspire:raw_cuhcat_nugget').food(food => {
    food
    .hunger(2)
    .saturation(1)
    })
})

StartupEvents.registry('item', event => { 
    event.create('ashspire:cuhcat_nugget').food(food => {
    food
    .hunger(6)
    .saturation(1)
    .removeEffect('minecraft:poison')
})
})
StartupEvents.registry('item', event => { 
    event.create('ashspire:cuhcat_mold')
    .displayName('Cuhcat Mold')
    .unstackable()
    
})