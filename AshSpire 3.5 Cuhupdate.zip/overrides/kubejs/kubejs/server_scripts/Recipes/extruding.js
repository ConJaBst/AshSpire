ServerEvents.recipes(event => {
    //Andesite Logical Recipe
    event.recipes.createMechanicalExtruderExtruding(Item.of('minecraft:andesite'), [Fluid.of('minecraft:lava'), Fluid.of('minecraft:water')]).withCatalyst('minecraft:magma_block').requiredBonks(4)
    //Granite Logical Recipe 
    event.recipes.createMechanicalExtruderExtruding(Item.of('minecraft:granite'), [Item.of('minecraft:magma_block'), Item.of('minecraft:blue_ice')]).requiredBonks(2)
    //Diorite Recipe
    event.recipes.createMechanicalExtruderExtruding(Item.of('minecraft:diorite'), [Fluid.of('minecraft:lava'), Fluid.of('minecraft:lava')]).withCatalyst('minecraft:magma_block').requiredBonks(5)
    //Deepslate Recipe 
    event.recipes.createMechanicalExtruderExtruding(Item.of('minecraft:cobbled_deepslate'), [Fluid.of('minecraft:lava'), Fluid.of('minecraft:lava')]).requiredBonks(4)
    //Sandstone Recipe
    event.recipes.createMechanicalExtruderExtruding(Item.of('minecraft:sandstone'), [Item.of('minecraft:sand'), Item.of('minecraft:sand')]).withCatalyst('minecraft:sand').requiredBonks(4)
    //Ice recipe
    event.recipes.createMechanicalExtruderExtruding(Item.of('minecraft:ice'), [Fluid.of('minecraft:water'), Item.of('minecraft:snow_block')]).withCatalyst('minecraft:snow_block').requiredBonks(9)
    //Netherrack Recipe 
    event.recipes.createMechanicalExtruderExtruding(Item.of('minecraft:netherrack'), [Fluid.of('minecraft:lava'), Fluid.of('minecraft:lava')]).withCatalyst('minecraft:nether_wart_block')
})

ServerEvents.recipes(event => {
    //Blasting Casings I guess Was suggested by Ignatius_real
    event.recipes.createMechanicalExtruderExtruding(Item.of('minecraft:cobblestone'), [Item.of('create_connected:fan_blasting_catalyst'), Item.of('create_connected:fan_splashing_catalyst')])
    event.recipes.createMechanicalExtruderExtruding(Item.of('minecraft:stone'), [Item.of('create_connected:fan_blasting_catalyst'), Item.of('create_connected:fan_splashing_catalyst')])
})